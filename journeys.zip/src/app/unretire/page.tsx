import Link from "next/link";
import Image from "next/image";
import NewsletterForm from "./NewsletterForm";

const challenges = [
  {
    title: "Loss of Structure",
    desc: "At first, retirement feels like a long weekend. Then a long vacation. Then a blur. Days blend into each other. The calendar that once commanded your attention sits empty.",
    icon: (
      <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#8B1A1A" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round">
        <rect x="3" y="3" width="7" height="7" rx="1.5" />
        <rect x="14" y="3" width="7" height="7" rx="1.5" />
        <rect x="3" y="14" width="7" height="7" rx="1.5" />
        <rect x="14" y="14" width="7" height="7" rx="1.5" />
      </svg>
    ),
  },
  {
    title: "Loss of Identity",
    desc: "You're safe. Comfortable. Respected for who you were. Yet something inside asks an uncomfortable question: \u201CIs this it?\u201D Not because you want more success — but because you want more life.",
    icon: (
      <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#8B1A1A" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round">
        <circle cx="12" cy="12" r="9.5" />
        <circle cx="12" cy="12" r="3" />
        <line x1="12" y1="2.5" x2="12" y2="8.5" />
      </svg>
    ),
  },
  {
    title: "Loss of Purpose",
    desc: "No one warns you about this part. They told you retirement is freedom. What they didn't tell you: retirement done wrong doesn't feel like freedom. It feels like drift.",
    icon: (
      <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#8B1A1A" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round">
        <circle cx="12" cy="12" r="9.5" />
        <path d="M12 7.5v4.8l3.2 3.2" />
      </svg>
    ),
  },
];

const mindsets = [
  {
    title: "Freedom",
    desc: "Design life on your own terms.",
    icon: (
      <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#8B1A1A" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round">
        <path d="M5 19 19 5M19 5h-7M19 5v7" />
      </svg>
    ),
  },
  {
    title: "Evolution",
    desc: "Growth continues throughout life.",
    icon: (
      <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#8B1A1A" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round">
        <path d="M3 17l6-6 4 4 7-7M21 8V4h-4" />
      </svg>
    ),
  },
  {
    title: "Balance",
    desc: "Harmony across all dimensions.",
    icon: (
      <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#8B1A1A" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round">
        <path d="M12 3v18M5 7h14M5 7l-2.5 6a4 4 0 0 0 5 0L5 7Zm14 0-2.5 6a4 4 0 0 0 5 0L19 7Z" />
      </svg>
    ),
  },
  {
    title: "Relevance",
    desc: "You don't have an expiry date.",
    icon: (
      <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#8B1A1A" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round">
        <circle cx="12" cy="12" r="9.5" />
        <circle cx="12" cy="12" r="5" />
        <circle cx="12" cy="12" r="0.8" fill="#8B1A1A" />
      </svg>
    ),
  },
  {
    title: "Joy",
    desc: "Curiosity and play are essential.",
    icon: (
      <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#8B1A1A" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round">
        <circle cx="12" cy="12" r="9.5" />
        <path d="M8.5 14.5a4 4 0 0 0 7 0M9 9.5h.01M15 9.5h.01" />
      </svg>
    ),
  },
];

const practices = ["Ignite", "Move", "Connect", "Contribute", "Explore", "Grow", "Optimize"];

const profiles = [
  { href: "/unretire/profile/status-dropper", title: "The Status Dropper", quote: "\u201CI didn't realise how much my title defined me.\u201D" },
  { href: "/unretire/profile/comfortable-drifter", title: "The Comfortable Drifter", quote: "\u201CLife is pleasant... but it feels a little flat.\u201D" },
  { href: "/unretire/profile/family-first-caretaker", title: "The Family-First Caretaker", quote: "\u201CMy time now revolves around family.\u201D" },
  { href: "/unretire/profile/still-ambitious-builder", title: "The Still-Ambitious Builder", quote: "\u201CI'm not finished creating.\u201D" },
  { href: "/unretire/profile/health-reset-retiree", title: "The Health Reset Retiree", quote: "\u201CNow it's time to take care of myself.\u201D" },
  { href: "/unretire/profile/forced-retiree", title: "The Forced Retiree", quote: "\u201CI didn't choose this transition.\u201D" },
];

const bookFeatures = [
  "5 Transformational Mindsets: Freedom, Evolution, Balance, Relevance, Joy",
  "7 Daily Practices: Ignite, Move, Connect, Contribute, Explore, Grow, Optimize",
  "Real stories from Japan, Kenya, Italy, Costa Rica, Jordan, and beyond",
  "The 14-Day Starter Plan to build real momentum immediately",
  "Companion Life Design Workbook with structured exercises",
];

export default function UnRetirePage() {
  return (
    <>
      {/* Fixed "back to Half a Life" pill */}
      <Link
        href="/"
        className="fixed bottom-5 right-5 z-[60] inline-flex items-center gap-1.5 bg-white/95 backdrop-blur-sm border border-[#E4DBCF] text-[#4A443B] hover:text-[#8B1A1A] text-[11px] font-bold tracking-[0.1em] uppercase rounded-full px-4 py-2 shadow-[0_6px_20px_-8px_rgba(0,0,0,0.25)] transition-colors"
      >
        ← Half a Life
      </Link>

      {/* ── HERO ─────────────────────────────────────────────── */}
      <section className="bg-white">
        <div className="max-w-7xl mx-auto px-5 sm:px-6 lg:px-8 py-16 sm:py-20 lg:py-24">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-center">
            <div className="lg:col-span-6 order-2 lg:order-1 text-center lg:text-left">
              <p className="eyebrow mb-6">Life after work is just the beginning</p>
              <h1 className="text-5xl sm:text-6xl lg:text-7xl font-bold tracking-[0.02em]">
                <span className="text-[#8B1A1A]">UN</span>RETIRE
              </h1>
              <span className="rule mt-7 mb-7 mx-auto lg:mx-0" aria-hidden="true" />
              <p className="font-bold italic text-2xl sm:text-3xl text-[#14110D] leading-snug mb-5">
                Reboot. Don&apos;t Mute.
              </p>
              <p className="lede max-w-[46ch] mx-auto lg:mx-0 mb-9">
                Retirement is not a finish line. It&apos;s an inflection point — and the framework
                to design what comes next starts here.
              </p>
              <div className="flex flex-wrap gap-3 justify-center lg:justify-start">
                <Link href="/unretire/framework" className="btn btn-crimson">
                  Explore the Framework
                </Link>
                <Link href="/unretire/book" className="btn btn-outline">
                  The Book
                </Link>
              </div>
            </div>

            <div className="lg:col-span-6 order-1 lg:order-2">
              <div className="relative mx-auto w-full max-w-[300px] sm:max-w-[340px]">
                <div className="absolute -inset-8 bg-[radial-gradient(ellipse,rgba(139,26,26,0.10),transparent_70%)]" aria-hidden="true" />
                <Image
                  src="/assets/images/1.png"
                  alt="UnRetire by Maher Kaddoura"
                  width={340}
                  height={468}
                  priority
                  className="relative w-full h-auto drop-shadow-[0_28px_56px_rgba(20,17,13,0.28)]"
                />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ── INTRO + VIDEO ────────────────────────────────────── */}
      <section className="bg-[#FAF5F0] border-y border-[#ECE5DB]">
        <div className="max-w-6xl mx-auto px-5 sm:px-6 lg:px-8 py-16 sm:py-20">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-10 lg:gap-16 items-center">
            {/* Video card */}
            <div className="card overflow-hidden">
              <div className="aspect-video bg-[#14110D] flex flex-col items-center justify-center text-center px-6 cursor-pointer">
                <span className="w-14 h-14 rounded-full bg-[#8B1A1A] flex items-center justify-center mb-4 shadow-[0_8px_24px_rgba(139,26,26,0.45)]">
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="#fff" aria-hidden="true">
                    <polygon points="6 3 20 12 6 21 6 3" />
                  </svg>
                </span>
                <p className="font-bold text-white text-[1.05rem] mb-1">Watch the UnRetire message</p>
                <p className="text-[13px] text-white/55 leading-snug max-w-xs">
                  Maher&apos;s personal message about what it means to UnRetire
                </p>
              </div>
              <div className="flex items-center gap-3 px-5 py-3 bg-[#1D1812]">
                <span className="bg-[#8B1A1A] text-white text-[9px] font-extrabold leading-tight tracking-[0.1em] uppercase rounded px-2 py-1 text-center">
                  New<br />Chapter
                </span>
                <p className="text-[13px] text-white/55 leading-snug">
                  Reboot. Don&apos;t Mute. The beginning of an intentional next chapter.
                </p>
              </div>
            </div>

            {/* Intro text */}
            <div>
              <p className="eyebrow mb-5">New Chapter</p>
              <p className="text-[1.35rem] sm:text-[1.5rem] leading-[1.5] text-[#2A251E]">
                Retirement is the only major life transition we prepare for{" "}
                <span className="text-[#8B1A1A] font-bold">financially</span> — but avoid{" "}
                <span className="text-[#8B1A1A] font-bold">emotionally</span>. (Un)Retire gives you
                the framework to design what comes next — on purpose, not by default.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* ── THE PROBLEM ──────────────────────────────────────── */}
      <section className="bg-white">
        <div className="max-w-6xl mx-auto px-5 sm:px-6 lg:px-8 py-16 sm:py-20 lg:py-24">
          <div className="max-w-2xl mx-auto text-center mb-12 sm:mb-16">
            <p className="eyebrow mb-5">The Challenge</p>
            <h2 className="text-3xl sm:text-4xl lg:text-[2.75rem]">The Problem with Retirement</h2>
            <span className="rule mt-6 mb-6 mx-auto" aria-hidden="true" />
            <p className="lede">
              For generations, retirement has been framed as the reward for a lifetime of work — a
              time to slow down, step aside, and finally rest.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
            {challenges.map((c) => (
              <div key={c.title} className="card card-hover p-7">
                <span className="icon-block mb-5">{c.icon}</span>
                <h3 className="text-xl mb-3">{c.title}</h3>
                <p className="prose-body text-[15px] text-[#4A443B] leading-[1.75]">{c.desc}</p>
              </div>
            ))}
          </div>

          {/* Pull quote */}
          <figure className="max-w-3xl mx-auto text-center mt-14 sm:mt-16">
            <span className="rule mx-auto mb-7" aria-hidden="true" />
            <blockquote className="text-2xl sm:text-[1.75rem] italic leading-[1.45] text-[#14110D]">
              &ldquo;The real risk is not aging. It&apos;s muting yourself — your curiosity, your
              contribution, your sense of relevance, your joy.&rdquo;
            </blockquote>
            <figcaption className="mt-5 text-[15px] italic text-[#837A6E]">
              &ldquo;Retirement is not a finish line. It&apos;s an inflection point — a new
              beginning.&rdquo;
            </figcaption>
          </figure>
        </div>
      </section>

      {/* ── PHILOSOPHY ───────────────────────────────────────── */}
      <section className="bg-[#FAF5F0] border-y border-[#ECE5DB]">
        <div className="max-w-6xl mx-auto px-5 sm:px-6 lg:px-8 py-16 sm:py-20 lg:py-24">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-10 lg:gap-16 items-center">
            <div>
              <p className="eyebrow mb-5">The Philosophy</p>
              <h2 className="text-3xl sm:text-4xl lg:text-[2.5rem] leading-tight">
                A New Way to Think About Retirement
              </h2>
              <span className="rule mt-6 mb-7" aria-hidden="true" />
              <p className="prose-body text-[#4A443B] leading-[1.8] mb-4">
                (Un)Retire is not about working forever. It&apos;s not about staying busy. It&apos;s
                not about denying age or pretending nothing has changed.
              </p>
              <p className="prose-body text-[#4A443B] leading-[1.8] mb-6">
                It&apos;s about <strong className="text-[#14110D] font-bold">rebooting</strong> your
                identity when old labels fall away.{" "}
                <strong className="text-[#14110D] font-bold">Choosing</strong> purpose over drift.{" "}
                <strong className="text-[#14110D] font-bold">Designing</strong> a life that feels
                whole — not just comfortable.
              </p>
              <p className="italic text-[1.15rem] text-[#8B1A1A]">Not by default — but by design.</p>
            </div>

            {/* Core equation */}
            <div className="card relative overflow-hidden p-10 sm:p-12 text-center before:content-[''] before:absolute before:inset-x-0 before:top-0 before:h-[3px] before:bg-[#8B1A1A]">
              <p className="eyebrow mb-7">The Core Equation</p>
              <p className="text-5xl sm:text-6xl font-bold text-[#14110D] leading-none">Mindset</p>
              <p className="text-3xl text-[#8B1A1A] font-bold my-3">&times;</p>
              <p className="text-5xl sm:text-6xl font-bold text-[#14110D] leading-none">Practice</p>
              <p className="prose-body text-[15px] text-[#4A443B] leading-[1.8] mt-7 mb-8 max-w-sm mx-auto">
                Five powerful mindsets. Seven intentional practices. Together, a complete guide for
                the next chapter of life.
              </p>
              <Link href="/unretire/framework" className="btn btn-crimson">
                Explore the Framework
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* ── THE FRAMEWORK ────────────────────────────────────── */}
      <section className="bg-white">
        <div className="max-w-6xl mx-auto px-5 sm:px-6 lg:px-8 py-16 sm:py-20 lg:py-24">
          <div className="text-center max-w-2xl mx-auto mb-12 sm:mb-14">
            <p className="eyebrow mb-5">The Framework</p>
            <h2 className="text-3xl sm:text-4xl lg:text-[2.75rem]">Five Mindsets. Seven Practices.</h2>
            <span className="rule mt-6 mb-6 mx-auto" aria-hidden="true" />
            <p className="lede">The building blocks of an intentional life after career.</p>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4 mb-8">
            {mindsets.map((m) => (
              <div key={m.title} className="card card-hover p-6 text-center flex flex-col items-center">
                <span className="icon-block mb-4">{m.icon}</span>
                <h3 className="text-[1.15rem] mb-1.5">{m.title}</h3>
                <p className="text-[13px] text-[#837A6E] leading-snug">{m.desc}</p>
              </div>
            ))}
          </div>

          <div className="rounded-2xl bg-[#14110D] px-5 py-5 flex flex-wrap items-center justify-center gap-x-2 gap-y-2">
            {practices.map((p) => (
              <Link
                key={p}
                href={`/unretire/framework/practice-${p.toLowerCase()}`}
                className="px-4 py-2 rounded-full text-[11px] font-bold tracking-[0.14em] uppercase text-white/65 hover:text-white hover:bg-white/10 transition-colors"
              >
                {p}
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* ── PROFILES ─────────────────────────────────────────── */}
      <section className="bg-[#FAF5F0] border-y border-[#ECE5DB]">
        <div className="max-w-5xl mx-auto px-5 sm:px-6 lg:px-8 py-16 sm:py-20 lg:py-24">
          <div className="text-center max-w-2xl mx-auto mb-12">
            <p className="eyebrow mb-5">Is this you?</p>
            <h2 className="text-3xl sm:text-4xl lg:text-[2.75rem]">Which Retiree Are You?</h2>
            <span className="rule mt-6 mb-6 mx-auto" aria-hidden="true" />
            <p className="lede">
              The (Un)Retire journey speaks to people at many different points in the retirement
              transition.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {profiles.map((p) => (
              <Link
                key={p.href}
                href={p.href}
                className="card card-hover relative p-6 block before:content-[''] before:absolute before:inset-x-0 before:top-0 before:h-[3px] before:bg-[#8B1A1A] before:opacity-0 hover:before:opacity-100 before:transition-opacity"
              >
                <h3 className="text-[1.1rem] mb-2">{p.title}</h3>
                <p className="text-[14px] italic text-[#837A6E] leading-snug">{p.quote}</p>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* ── BUY THE BOOK ─────────────────────────────────────── */}
      <section className="bg-white">
        <div className="max-w-5xl mx-auto px-5 sm:px-6 lg:px-8 py-16 sm:py-20 lg:py-24">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-center">
            <div className="lg:col-span-5 flex justify-center">
              <Image
                src="/assets/images/book-unretire-cover.png"
                alt="UnRetire book cover"
                width={260}
                height={360}
                className="w-full max-w-[240px] h-auto rounded-md drop-shadow-[0_24px_52px_rgba(20,17,13,0.28)]"
              />
            </div>
            <div className="lg:col-span-7">
              <h2 className="text-2xl sm:text-3xl lg:text-[2.25rem] leading-tight mb-5">
                The complete guide to designing your next chapter
              </h2>
              <p className="prose-body text-[#4A443B] leading-[1.8] mb-7">
                From &ldquo;Reboot Don&apos;t Mute&rdquo; to the 14-Day Starter Plan — a
                comprehensive framework for approaching retirement not as an end, but as a beginning.
              </p>
              <ul className="space-y-3 mb-9">
                {bookFeatures.map((f) => (
                  <li key={f} className="flex items-start gap-3">
                    <span className="text-[#8B1A1A] mt-1 flex-shrink-0" aria-hidden="true">
                      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                        <path d="M20 6 9 17l-5-5" />
                      </svg>
                    </span>
                    <span className="text-[15px] text-[#4A443B] leading-[1.7]">{f}</span>
                  </li>
                ))}
              </ul>
              <a
                href="https://amazon.com"
                target="_blank"
                rel="noopener noreferrer"
                className="btn btn-crimson"
              >
                Buy on Amazon →
              </a>
            </div>
          </div>
        </div>
      </section>

      {/* ── NEWSLETTER ───────────────────────────────────────── */}
      <section className="bg-[#8B1A1A]">
        <div className="max-w-2xl mx-auto px-5 sm:px-6 lg:px-8 py-16 sm:py-20 text-center">
          <h2 className="text-3xl sm:text-4xl lg:text-[2.5rem] text-white leading-tight">
            Join the (Un)Retire Newsletter
          </h2>
          <span className="block w-12 h-[3px] bg-white/80 rounded-full mx-auto mt-6 mb-6" aria-hidden="true" />
          <p className="text-white/80 text-[16px] leading-[1.7] mb-9 max-w-md mx-auto">
            Weekly insights on designing the life you were made for — delivered every Monday morning.
          </p>
          <NewsletterForm />
        </div>
      </section>
    </>
  );
}
