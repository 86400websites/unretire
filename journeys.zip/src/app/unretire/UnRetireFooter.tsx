import Link from "next/link";

const columns = [
  {
    title: "Explore",
    links: [
      { label: "The Book", href: "/unretire/book" },
      { label: "Framework", href: "/unretire/framework" },
      { label: "Start Here", href: "/unretire/start" },
      { label: "Articles", href: "/unretire/articles" },
    ],
  },
  {
    title: "Journey",
    links: [
      { label: "Journeys", href: "/unretire/journeys" },
      { label: "Tools", href: "/unretire/tools" },
      { label: "Community", href: "/unretire/community" },
      { label: "Course", href: "/unretire/course" },
    ],
  },
  {
    title: "Connect",
    links: [
      { label: "Newsletter", href: "/unretire/newsletter" },
      { label: "Speaking", href: "/unretire/speaking" },
      { label: "Contact", href: "/unretire/contact" },
    ],
  },
];

export default function UnRetireFooter() {
  return (
    <footer className="bg-[#14110D] text-white">
      <div className="max-w-6xl mx-auto px-5 sm:px-6 lg:px-8 pt-16 pb-10">
        <div className="grid grid-cols-2 md:grid-cols-12 gap-10 pb-12 border-b border-white/10">
          {/* Brand */}
          <div className="col-span-2 md:col-span-5">
            <div className="flex items-baseline gap-[3px] mb-4">
              <span className="text-xl font-bold tracking-[0.04em] text-white">UN</span>
              <span className="text-xl font-normal tracking-[0.04em] text-white/45">RETIRE</span>
            </div>
            <p className="text-[14px] leading-relaxed text-white/55 max-w-[260px] mb-6">
              Reboot. Don&apos;t Mute. Design your next chapter with intention, purpose, and joy.
            </p>
            <Link
              href="/"
              className="inline-flex items-center gap-2 text-[11px] font-bold tracking-[0.12em] uppercase text-white/55 hover:text-white transition-colors border border-white/15 rounded-full px-3.5 py-1.5"
            >
              <span className="relative inline-block w-3 h-3 rounded-full overflow-hidden flex-shrink-0">
                <span className="absolute left-0 top-0 w-1/2 h-full bg-white" />
                <span className="absolute right-0 top-0 w-1/2 h-full bg-[#8B1A1A]" />
              </span>
              Part of Half a Life
            </Link>
          </div>

          {/* Link columns */}
          {columns.map((col) => (
            <div key={col.title} className="md:col-span-2">
              <p className="text-[11px] font-bold tracking-[0.18em] uppercase text-white/35 mb-4">
                {col.title}
              </p>
              <ul className="space-y-3">
                {col.links.map((l) => (
                  <li key={l.href}>
                    <Link
                      href={l.href}
                      className="text-[14px] text-white/55 hover:text-white transition-colors"
                    >
                      {l.label}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 pt-7">
          <p className="text-[12px] text-white/35">
            © 2026 UnRetire · Maher Kaddoura · Part of Half a Life
          </p>
          <div className="flex gap-6">
            <Link href="/privacy" className="text-[12px] text-white/35 hover:text-white/70 transition-colors">
              Privacy
            </Link>
            <Link href="/terms" className="text-[12px] text-white/35 hover:text-white/70 transition-colors">
              Terms
            </Link>
          </div>
        </div>
      </div>
    </footer>
  );
}
