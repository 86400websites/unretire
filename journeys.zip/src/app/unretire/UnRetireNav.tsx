"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";

const links = [
  { label: "The Book", href: "/unretire/book" },
  { label: "Framework", href: "/unretire/framework" },
  { label: "Articles", href: "/unretire/articles" },
  { label: "Journeys", href: "/unretire/journeys" },
  { label: "Community", href: "/unretire/community" },
];

export default function UnRetireNav() {
  const [open, setOpen] = useState(false);
  const pathname = usePathname() ?? "/unretire";
  const isActive = (href: string) => pathname === href || pathname.startsWith(href + "/");

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && setOpen(false);
    document.addEventListener("keydown", onKey);
    return () => document.removeEventListener("keydown", onKey);
  }, []);

  return (
    <>
      <header className="sticky top-0 z-50 bg-white/95 backdrop-blur-sm border-b border-[#ECE5DB]">
        <div className="max-w-7xl mx-auto px-5 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-[70px] gap-4">
            {/* Logo */}
            <Link
              href="/unretire"
              aria-label="UnRetire — home"
              className="flex items-baseline gap-[3px] flex-shrink-0"
            >
              <span className="text-[1.35rem] font-bold tracking-[0.04em] text-[#8B1A1A]">UN</span>
              <span className="text-[1.35rem] font-normal tracking-[0.04em] text-[#14110D]">RETIRE</span>
            </Link>

            {/* Desktop links */}
            <nav className="hidden lg:flex items-center gap-1" aria-label="UnRetire">
              {links.map((l) => {
                const active = isActive(l.href);
                return (
                  <Link
                    key={l.href}
                    href={l.href}
                    aria-current={active ? "page" : undefined}
                    className={`px-3.5 py-2 rounded-full text-[12px] font-bold tracking-[0.1em] uppercase transition-colors ${
                      active
                        ? "bg-[#F6EDE6] text-[#8B1A1A]"
                        : "text-[#4A443B] hover:text-[#8B1A1A] hover:bg-[#FAF5F0]"
                    }`}
                  >
                    {l.label}
                  </Link>
                );
              })}
            </nav>

            {/* Desktop CTA */}
            <div className="hidden lg:flex items-center">
              <Link href="/unretire/community" className="btn btn-crimson">
                Join
              </Link>
            </div>

            {/* Mobile toggle */}
            <button
              type="button"
              onClick={() => setOpen((v) => !v)}
              aria-label={open ? "Close menu" : "Open menu"}
              aria-expanded={open}
              aria-controls="ur-mobile-menu"
              className="lg:hidden p-2 -mr-2 text-[#14110D]"
            >
              {open ? (
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" aria-hidden="true">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18 18 6M6 6l12 12" />
                </svg>
              ) : (
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" aria-hidden="true">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
                </svg>
              )}
            </button>
          </div>
        </div>

        {/* Mobile menu */}
        {open && (
          <div id="ur-mobile-menu" className="lg:hidden border-t border-[#ECE5DB] bg-white">
            <div className="px-5 sm:px-6 py-4 space-y-1">
              {links.map((l) => {
                const active = isActive(l.href);
                return (
                  <Link
                    key={l.href}
                    href={l.href}
                    onClick={() => setOpen(false)}
                    aria-current={active ? "page" : undefined}
                    className={`block px-3 py-3 rounded-xl text-[12px] font-bold tracking-[0.1em] uppercase transition-colors ${
                      active ? "bg-[#F6EDE6] text-[#8B1A1A]" : "text-[#2A251E] hover:bg-[#FAF5F0]"
                    }`}
                  >
                    {l.label}
                  </Link>
                );
              })}

              <div className="pt-3 mt-2 border-t border-[#ECE5DB] space-y-2">
                <Link
                  href="/"
                  onClick={() => setOpen(false)}
                  className="block px-3 py-2.5 text-[12px] font-bold tracking-[0.12em] uppercase text-[#837A6E] hover:text-[#8B1A1A] transition-colors"
                >
                  ← Back to Half a Life
                </Link>
                <Link
                  href="/unretire/community"
                  onClick={() => setOpen(false)}
                  className="btn btn-crimson w-full"
                >
                  Join
                </Link>
              </div>
            </div>
          </div>
        )}
      </header>
    </>
  );
}
