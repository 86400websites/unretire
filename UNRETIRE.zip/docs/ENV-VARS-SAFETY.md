# ENV-VARS-SAFETY.md — Environment Variables, In Plain English

The rules for handling configuration values and secrets on (Un)Retire. Read this once before touching any key; follow the procedures every time after.

## What env vars are

Environment variables are named values the app reads at build or run time — things like "which database URL do I talk to" or "what's the email provider's API key". They let the same code run in different environments (local, Preview, Production) with different values, and they keep secrets out of the code itself. The code references the NAME; the VALUE lives outside the repo.

## The two classes

**PUBLIC** — carries the selected framework's public prefix (for example, `NEXT_PUBLIC_*` in Next.js or `VITE_*` in Vite). Record the actual prefix in `TECH-ARCHITECTURE.md`.

- Inlined into the browser bundle **at build time**. Treat as world-readable, forever.
- Only ever: URLs, publishable/anon keys, and site config (e.g. `NEXT_PUBLIC_SITE_URL`).
- If you wouldn't print it on the homepage, it doesn't get the public prefix.

**PRIVATE** — everything else: provider API keys, secret keys, database credentials, JWT secrets.

- Read only in trusted server/build contexts defined by the locked framework.
- Never imported into browser code or passed through serialized props, HTML, logs, or error responses.

Why this matters: the prefix is not decoration — it is the boundary between "public forever" and "secret". One misprefixed key is a full leak.

## What never goes into client code

- The database secret / service-role key (it bypasses row-level security)
- Any provider API key or token (email, payments, CAPTCHA secret, rate limiter)
- Database passwords or connection strings
- JWT or session-signing secrets
- Webhook signing secrets
- Anything from a live env file that is not explicitly public

## What never gets committed

- `.env.local` or any project-specific live env file — ever. Confirm the selected filename is ignored on day one.
- Any file containing a real value — including docs, PR descriptions, and screenshots.
- The ONLY env file in git is `.env.example`: variable NAMES + safe placeholders, no real values. (Make sure `.gitignore` doesn't accidentally swallow it — whitelist with `!.env.example` if needed.)

> **(Un)Retire status — 2026-08-25 (Sprint S1.1): DONE.** The committed example is `.env.example`
> (placeholder-only, 1326 bytes) and `.gitignore` whitelists it with `!.env.example` beneath the blanket
> `.env*` rule — without that line the blanket rule hides it from git entirely. Verified 2026-08-25:
> `.env.example` is tracked; `.env.local` exists on the owner's machine, is git-ignored and untracked,
> and has never been opened by an agent.

**Never do this:** never paste a real key into a chat, a commit message, a code comment, or a "temporary" file. AI agents must not open, print, copy, or edit live env files. They verify ignore/tracked state without reading values.

## Where values live

| Context | Where the value lives |
|---|---|
| Local development | `.env.local` (gitignored, on the authorized operator's machine only) |
| Deployed Preview / Production | Vercel environment/secret settings, scoped per environment |

Same names everywhere; environment-specific values. Never copy a Production value into Preview.

## The change procedure (new or updated var)

1. Add the NAME (never the value) to `.env.example` and note it in the architecture doc, marked public or server-only.
2. The authorized owner sets the real value in the hosting/secret dashboard for each environment and in the ignored local env file where needed.
3. **Redeploy.** Existing deployments do not pick up changed values — and public values are baked in at build time, so they require a fresh build to take effect.
4. Verify the feature actually works on the deployed site, not just locally.

## The leak procedure

1. **Rotate the key immediately** at the provider. Do this FIRST — before any cleanup, before investigating how it happened.
2. The authorized owner updates the new value in every affected host environment and local machine; redeploy.
3. Then clean up: remove the value from wherever it leaked and fix the process that let it happen.
4. Record the incident in the decision/status log.

Why rotation comes first: git history, forks, caches, and screenshots are forever — the key was compromised the moment it was exposed. Scrubbing history is not a fix; a dead key is.

## Quick reference

| Value type | Example NAME | Public or private | Where it lives |
|---|---|---|---|
| Site URL | `NEXT_PUBLIC_SITE_URL` | Public | Local + approved host environments |
| Database URL *(Supabase example)* | `NEXT_PUBLIC_SUPABASE_URL` | Public | Local + approved host environments |
| Publishable key *(Supabase example)* | `NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY` | Public | Local + approved host environments |
| Email provider key *(example)* | `MAILCHIMP_API_KEY` | Private | Trusted local/server secret stores |
| Database secret key *(optional)* | `SUPABASE_SECRET_KEY` | Private | Trusted server secret store; avoid unless required |
| Bot-protection secret *(example)* | N/A — none wired yet (required before launch, Sprint S4.5) | Private | Trusted local/server secret stores |

The names above are patterns, not required variables. Delete unused rows and never fill a value into this document.

Next step → record the selected host/env model in `docs/TECH-ARCHITECTURE.md`; use `docs/SUPABASE-VERCEL-SETUP.md` only when that profile is selected.
